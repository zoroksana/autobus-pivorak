Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  devise_for :users, controllers: {
      sessions: 'users/sessions',
      passwords: 'users/passwords',
      registrations: 'users/registrations',
  }

  devise_scope :user do
    authenticated :user do
      root 'bus_lines#index'
    end

    unauthenticated do
      root 'devise/sessions#new'
    end
  end

  resources :users do
    resources :tickets
  end

  resources :bus_lines do
    resources :tickets
  end
end
