Rails.application.configure do
  config.action_mailer.default_options = {
      from: 'notification@example.com'
  }
  config.action_mailer.delivery_method = :smtp
  config.action_mailer.smtp_settings = {
      address: 'smtp.gmail.com',
      port: 587,
      domain: 'vevidi.com',
      user_name: 'notification@vevidi.com',
      password: '!vevidi_notification2',
      authentication: 'plain',
      enable_starttls_auto: true
  }
end