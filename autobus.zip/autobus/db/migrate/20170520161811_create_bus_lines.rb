class CreateBusLines < ActiveRecord::Migration[5.0]
  def change
    create_table :bus_lines do |t|
      t.integer :seats, default: 1
      t.string :departure, default: ''
      t.datetime :departure_time, default: nil
      t.string :arrival, default: ''
      t.datetime :arrival_time, default: nil
      t.timestamps
    end
  end
end
