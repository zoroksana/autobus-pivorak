class Ticket < ApplicationRecord

  belongs_to :bus_line
  belongs_to :user

  validates :place, presence: true, uniqueness: {scope: :bus_line_id }

end
