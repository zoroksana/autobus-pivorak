class BusLine < ApplicationRecord

  has_many :tickets, dependent: :destroy
  has_many :users, through: :tickets

  def title
    [self.departure, self.arrival].join('-')
  end

end
