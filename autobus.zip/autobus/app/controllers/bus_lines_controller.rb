class BusLinesController < BaseController
  before_action :set_bus_line, only: [:show, :edit, :update, :destroy]

  # GET /bus_lines
  def index
    @bus_lines = BusLine.all
  end

  # GET /bus_lines/1
  def show
    render action: :edit
  end

  # GET /bus_lines/new
  def new
    @bus_line = BusLine.new
    render action: :edit
  end

  # GET /bus_lines/1/edit
  def edit
  end

  # POST /bus_lines
  def create
    @bus_line = BusLine.new(bus_line_params)

    respond_to do |format|
      if @bus_line.save
        format.html {
          flash.notice = 'Маршрут успішно створено.'
          redirect_to bus_lines_path
        }
      else
        format.html {
          flash.now.alert = 'Виправіть помилки.'
          render action: :edit
        }
      end
    end
  end

  # PATCH/PUT /bus_lines/1
  def update
    respond_to do |format|
      if @bus_line.update(bus_line_params)
        format.html {
          flash.notice = 'Маршрут успішно оновлено.'
          redirect_to action: :index
        }
      else
        format.html {
          flash.now.alert = 'Виправіть помилки.'
          render action: :edit
        }
      end
    end
  end

  # DELETE /bus_lines/1
  def destroy
    @bus_line.destroy
    respond_to do |format|
      format.html {
        flash.notice = 'Маршрут успішно видалено.'
        redirect_to action: :index
      }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_bus_line
    @bus_line = BusLine.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def bus_line_params
    params.require(:bus_line).permit(:seats, :departure, :departure_time, :arrival, :arrival_time)
  end
end
