class TicketsController < BaseController
  before_action :set_data
  before_action :set_ticket, only: [:show, :edit, :update, :destroy]

  # GET /tickets
  def index
    @tickets = if @user
                 @user.tickets.all
               elsif @bus_line
                 @bus_line.tickets.all
               else
                 []
               end
  end

  # GET /tickets/1
  def show
  end

  # GET /tickets/new
  def new
    @ticket = @bus_line.tickets.new
    render action: :edit
  end

  # GET /tickets/1/edit
  def edit
  end

  # POST /tickets
  def create
    @ticket = current_user.tickets.new(ticket_params)

    respond_to do |format|
      if @ticket.save
        format.html {
          flash.notice = 'Квиток успішно куплено.'
          redirect_to bus_lines_path
        }
      else
        format.html {
          flash.alert = 'Обране місце зайняте.'
          redirect_to new_bus_line_ticket_path(@bus_line)
        }
      end
    end
  end

  # PATCH/PUT /tickets/1
  def update
    respond_to do |format|
      if @ticket.update(ticket_params)
        format.html {redirect_to @ticket, notice: 'Ticket was successfully updated.'}
      else
        format.html {render :edit}
      end
    end
  end

  # DELETE /tickets/1
  def destroy
    @ticket.destroy
    respond_to do |format|
      format.html {redirect_to tickets_url, notice: 'Ticket was successfully destroyed.'}
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_data
    @bus_line = BusLine.find(params[:bus_line_id]) rescue nil
    @user = User.find(params[:user_id]) rescue nil
  end

  def set_ticket
    @ticket = @bus_line.tickets.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def ticket_params
    params.require(:ticket).permit(:user_id, :bus_line_id, :place)
  end
end
